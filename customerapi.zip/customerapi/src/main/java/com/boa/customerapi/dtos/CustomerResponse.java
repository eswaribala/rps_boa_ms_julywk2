package com.boa.customerapi.dtos;

import lombok.Data;

@Data
public class CustomerResponse {

	private long customerId;
	private long mobileNo;
}
