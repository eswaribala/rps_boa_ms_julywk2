package com.boa.customer.configurations;

import org.springframework.stereotype.Component;

@Component
public class Required {

}
