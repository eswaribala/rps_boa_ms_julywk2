package com.boa.customerapi.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.customerapi.models.Customer;
import com.boa.customerapi.models.FullName;
import com.boa.customerapi.models.GenderType;
import com.boa.customerapi.repositories.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	//insert
	
	public Customer addCustomer(Customer customer)
	{
		return this.customerRepository.save(customer);
	}
	
	
	//select all
	
	public List<Customer> getAllCustomers()
	{
		return this.customerRepository.findAll();
	}
	
	//select by id
	
	public Customer getCustomerById(long customerId)
	{
		return this.customerRepository.findById(customerId).orElse(null);
	}
	//update
	
	public Customer updateCustomer(Customer customer)
	{
		return this.customerRepository.save(customer);
	}
	
	
	//delete by id
	
	public boolean deleteByCustomerId (long customerId)
	{
		boolean status=false;
		 this.customerRepository.deleteById(customerId);
		 Customer customer=getCustomerById(customerId);
		 if (customer==null)
			 status=true;
		 return status;
		 
	}
	
	
	 @Transactional
	    public Customer createCustomer(final String firstName, final String lastName,final String email, final long mobileNo , final String dob, final String gender) {
	        final FullName fullName=new FullName();
	        fullName.setFirstName(firstName);
	        fullName.setLastName(lastName);
	        fullName.setMiddleName(null);
		    final Customer customer = new Customer();
	        customer.setName(fullName);
	        customer.setEmail(email);
	        customer.setMobileNo(mobileNo);
	        customer.setGender(GenderType.valueOf(gender));
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	       
	        //convert String to LocalDate
	        LocalDate localDate = LocalDate.parse(dob, formatter);
	        customer.setDob(localDate);
	        return this.customerRepository.save(customer);
	    }
}
